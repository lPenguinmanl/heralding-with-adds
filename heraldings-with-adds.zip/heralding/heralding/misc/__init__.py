import zmq

zmq_context = zmq.Context()
